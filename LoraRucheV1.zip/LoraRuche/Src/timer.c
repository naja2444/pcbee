#include <stdint.h>
#include "stm32g031xx.h"
#include "timer.h"

uint32_t SystemCoreClock = 16000000;
uint32_t ticks = 0;

void SYSTICK_Init(void){
	SysTick_Config(SystemCoreClock / 1000);
}

void SYSTICK_Delay(uint32_t Delay)
{
	uint32_t tickstart = SYSTICK_Get();
	uint32_t wait = Delay;

	while((SYSTICK_Get() - tickstart) < wait);
}

uint32_t SYSTICK_Get(void){
	return ticks;
}

//capteur temp

// --- GESTION DES MICROSECONDES (TIM3) ---

void Timer_Init_Microsecondes(void) {
    // 1. Activer l'horloge pour le Timer 3
    RCC->APBENR1 |= RCC_APBENR1_TIM3EN;

    // 2. Configurer la vitesse du compte (Prescaler)
    // Notre horloge est à 16 MHz. On veut 1 MHz (1 tick = 1 µs).
    // Calcul : (16 / 1) - 1 = 15
    TIM3->PSC = 15;

    // 3. Configurer la valeur max de comptage (Auto-Reload)
    TIM3->ARR = 0xFFFF; // Maximum possible (65535)

    // 4. Démarrer le chronomètre
    TIM3->CR1 |= TIM_CR1_CEN;
}

void Delai_us(uint32_t us) {
    // On note la valeur actuelle du compteur
    uint16_t temps_debut = TIM3->CNT;

    // On attend que la différence entre "maintenant" et "debut" atteigne la cible
    // (Le cast en uint16_t gère automatiquement le retour à zéro du compteur)
    while ((uint16_t)(TIM3->CNT - temps_debut) < us);
}
