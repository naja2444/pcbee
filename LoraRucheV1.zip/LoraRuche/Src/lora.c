#include "lora.h"
#include <stdio.h>
#include <string.h>
#include <stm32g031xx.h>

// --- DECLARATIONS EXTERNES (Pour utiliser ceux du main.c) ---
extern void UART_envoie_chaine(const char* str);
extern void UART_LireReponse_AvecDelai(char* buffer, int buffer_taille, uint32_t timeout_ms);

// --- VARIABLES PRIVEES ---
char rx_buffer_lora[128]; // Buffer
char cmd_buffer[128];     // Buffer pour sprintf

// *** CLES TTN ***
#define LORA_APP_EUI "526973696E674846"
#define LORA_APP_KEY "73B648C0D9EC9A79DC7C23A7EFC2A1F0"
#define LORA_DEV_EUI "2CF7F120510013D4"

// --- FONCTION UTILITAIRE  ---
static int check_erreur(const char* buffer) {
    if (strstr(buffer, "ERROR") != NULL) {
        return 1;
    }
    return 0;
}

// --- FONCTIONS LORA ---

void LoRa_Setup_And_Join(void) {
    // --- 1. CONFIGURATION (AVEC TIMEOUTS REDUITS) ---
    UART_envoie_chaine("AT+MODE=LWOTAA\r\n");
    // Utiliser un timeout court de 300ms au lieu de 2000ms
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    UART_envoie_chaine("AT+DR=EU868\r\n");
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    UART_envoie_chaine("AT+CLASS=A\r\n");
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    // --- 2. DEFINIR LES CLES (AVEC TIMEOUTS REDUITS) ---
    sprintf(cmd_buffer, "AT+ID=AppEui,%s\r\n", LORA_APP_EUI);
    UART_envoie_chaine(cmd_buffer);
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    sprintf(cmd_buffer, "AT+KEY=AppKey,%s\r\n", LORA_APP_KEY);
    UART_envoie_chaine(cmd_buffer);
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    sprintf(cmd_buffer, "AT+ID=DevEui,%s\r\n", LORA_DEV_EUI);
    UART_envoie_chaine(cmd_buffer);
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 300);
    if (check_erreur(rx_buffer_lora)) { while(1); } // Bloque si erreur

    // --- 3. REJOINDRE LE RESEAU (AVEC TIMEOUT REDUIT) ---
    UART_envoie_chaine("AT+JOIN\r\n");

    // Attendre
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 15000);

    // ON VERIFIE si le Join a réussi
    if (strstr(rx_buffer_lora, "Network joined") == NULL) {
        // Le Join a échoué
        while(1); // Bloque le programme
    }
}

void LoRa_Envoyer_Message(const char* message_hex) {
    // --- 4. ENVOI UNIQUE ---
    //message a envoyer
    sprintf(cmd_buffer, "AT+CMSGHEX=\"%s\"\r\n", message_hex);
    UART_envoie_chaine(cmd_buffer);

    // Attendre la réponse
    UART_LireReponse_AvecDelai(rx_buffer_lora, sizeof(rx_buffer_lora), 15000); // 15s
}
