#include "poids.h"
#include "timer.h" // Pour Delai_us
#include <stm32g031xx.h>

// Branchement : DT sur PB4, SCK sur PB5
#define PORT_POIDS GPIOB
#define PIN_DT     4
#define PIN_SCK    5

static int32_t valeur_tare = 0;

void Poids_GPIO_Init(void) {
    RCC->IOPENR |= RCC_IOPENR_GPIOBEN;

    // SCK (PB5) en SORTIE
    PORT_POIDS->MODER &= ~(GPIO_MODER_MODE5_1);
    PORT_POIDS->MODER |=  (GPIO_MODER_MODE5_0);

    // DT (PB4) en ENTREE
    PORT_POIDS->MODER &= ~(GPIO_MODER_MODE4_0 | GPIO_MODER_MODE4_1);
    PORT_POIDS->PUPDR |=  (GPIO_PUPDR_PUPD4_0); // Pull-up

    // SCK à 0 au repos
    PORT_POIDS->BRR = (1 << PIN_SCK);
}

// Fonction interne pour lire 24 bits
int32_t Poids_Lire_Unique(void) {
    uint32_t compte = 0;

    // Attendre que le HX711 soit prêt (DT passe à 0)
    // Ajout d'une sécurité anti-blocage (timeout simple)
    uint32_t timeout = 100000;
    while (PORT_POIDS->IDR & (1 << PIN_DT)) {
        timeout--;
        if(timeout == 0) return 0; // Erreur ou débranché
    }

    // Lire 24 bits
    for (int i = 0; i < 24; i++) {
        PORT_POIDS->BSRR = (1 << PIN_SCK); // Horloge HAUT
        Delai_us(1);
        compte = compte << 1;
        PORT_POIDS->BRR = (1 << PIN_SCK);  // Horloge BAS
        Delai_us(1);

        if (PORT_POIDS->IDR & (1 << PIN_DT)) {
            compte++;
        }
    }

    // 25ème impulsion (Gain 128)
    PORT_POIDS->BSRR = (1 << PIN_SCK);
    Delai_us(1);
    PORT_POIDS->BRR = (1 << PIN_SCK);
    Delai_us(1);

    // Conversion 24 bits signé vers 32 bits signé
    if (compte & 0x800000) {
        compte |= 0xFF000000;
    }
    return (int32_t)compte;
}

int32_t Poids_Lire_Moyenne(uint8_t nombre_lectures) {
    long long somme = 0;
    for (int i = 0; i < nombre_lectures; i++) {
        somme += Poids_Lire_Unique();
    }
    return (int32_t)(somme / nombre_lectures);
}

void Poids_Tare(void) {
    valeur_tare = Poids_Lire_Moyenne(10);
}

int32_t Poids_Obtenir_Valeur(void) {
    return (Poids_Lire_Moyenne(3) - valeur_tare);
}
