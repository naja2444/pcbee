#include <stdint.h>
#include <stdio.h>
#include <stm32g031xx.h>
#include "main.h"
#include "timer.h"
#include "usart.h"
#include "lora.h"
#include "onewire.h"
#include "poids.h" // <--- L'ajout final !

// VOTRE FACTEUR DE CALIBRATION
// Mettez ici la valeur trouvée lors de votre test (en positif)
#define FACTEUR_CALIBRATION 10750.0f

int main(void) {
    // --- 1. INITIALISATION MATERIEL ---
    SYSTICK_Init();             // Millisecondes
    Timer_Init_Microsecondes(); // Microsecondes (TIM3) pour les capteurs
    UART_Init();                // UART1 pour le module LoRa
    Onewire_GPIO_Init();        // PB0 pour Température
    Poids_GPIO_Init();          // PB4/PB5 pour Poids

    __enable_irq(); // Active les interruptions

    SYSTICK_Delay(1000); // Petite pause démarrage

    // --- 2. TARE DE LA BALANCE ---
    // On fait la tare AVANT de rejoindre le réseau.
    // Assurez-vous que rien n'est posé sur la balance au démarrage de la carte.
    Poids_Tare();

    // --- 3. CONNEXION LORA ---
    // Cette fonction bloque tant que la connexion n'est pas réussie (LED fixe à la fin)
    LoRa_Setup_And_Join();

    // Variables de travail
    uint8_t scratchpad[9];
    float temperature_lue = 0.0;
    int32_t poids_brut = 0;
    float poids_kg = 0.0;

    // --- 4. BOUCLE PRINCIPALE ---
    while(1)
    {
        // ============================================
        // A. LECTURE TEMPERATURE (DS18B20)
        // ============================================
        if (Onewire_Reset()) {
            Onewire_WriteByte(0xCC); // Skip ROM
            Onewire_WriteByte(0x44); // Start Convert
            SYSTICK_Delay(800);      // Attente conversion

            Onewire_Reset();
            Onewire_WriteByte(0xCC);
            Onewire_WriteByte(0xBE); // Read Scratchpad
            Onewire_ReadBytes(scratchpad, 9);

            temperature_lue = Onewire_ConvertToCelsius(scratchpad);
        } else {
            temperature_lue = 0.0; // Erreur capteur
        }

        // ============================================
        // B. LECTURE POIDS (HX711)
        // ============================================
        // 1. Récupérer la valeur brute (sans la tare)
        poids_brut = Poids_Obtenir_Valeur();

        // 2. Convertir en Kilos avec votre facteur
        poids_kg = (float)poids_brut / FACTEUR_CALIBRATION;

        // 3. Correction : Si c'est un tout petit peu négatif (bruit), on met 0
        if (poids_kg < 0.0f) poids_kg = 0.0f;

        // ============================================
        // C. PREPARATION DU MESSAGE LORA
        // ============================================
        // On multiplie par 100 pour envoyer des entiers (2 décimales)
        // Ex: 24.50°C -> 2450
        // Ex: 12.34kg -> 1234
        int16_t temp_int = (int16_t)(temperature_lue * 100);
        int16_t poids_int = (int16_t)(poids_kg * 100);

        char message_hex[20];
        // Format Hexa : 4 caractères Temp + 4 caractères Poids
        // Exemple généré : "099204D2" (pour 24.50°C et 12.34kg)
        sprintf(message_hex, "%04X%04X", temp_int, poids_int);

        // ============================================
        // D. ENVOI ET ATTENTE
        // ============================================
        LoRa_Envoyer_Message(message_hex);

        // Pause de 5 minutes (300 000 ms) pour une vraie ruche
        // Mettez 30 000 (30s) pour tester maintenant
        SYSTICK_Delay(30000);
    }
}
