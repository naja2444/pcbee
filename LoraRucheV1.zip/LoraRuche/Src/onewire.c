#include "onewire.h"
#include "timer.h" // Pour Delai_us
#include <stm32g031xx.h>

// Définition de la broche : Port B, Pin 0
#define PORT_ONEWIRE GPIOB
#define PIN_ONEWIRE  0

// --- FONCTIONS INTERNES (Configuration des broches) ---

void Onewire_GPIO_Init(void) {
    // Active l'horloge du Port B (sécurité)
    RCC->IOPENR |= RCC_IOPENR_GPIOBEN;
}

// Met la broche en mode SORTIE (pour envoyer des commandes)
static void Mode_Sortie(void) {
    PORT_ONEWIRE->MODER &= ~(GPIO_MODER_MODE0_1); // Reset bits
    PORT_ONEWIRE->MODER |=  (GPIO_MODER_MODE0_0); // Mode Sortie (01)
    PORT_ONEWIRE->OTYPER |= (1 << PIN_ONEWIRE);   // Mode Open-Drain
}

// Met la broche en mode ENTREE (pour écouter le capteur)
static void Mode_Entree(void) {
    PORT_ONEWIRE->MODER &= ~(GPIO_MODER_MODE0_0 | GPIO_MODER_MODE0_1); // Mode Entrée (00)
}

// --- PROTOCOLE ONEWIRE (Gestion des bits) ---

// Écrit un seul bit (0 ou 1)
static void Onewire_WriteBit(uint8_t bit) {
    Mode_Sortie();
    PORT_ONEWIRE->ODR &= ~(1 << PIN_ONEWIRE); // Tirer la ligne à 0 (BAS)

    if (bit) {
        // Si on veut écrire un '1'
        Delai_us(6);       // On tient la ligne basse peu de temps
        Mode_Entree();     // On relâche la ligne
        Delai_us(64);      // On attend la fin du créneau
    } else {
        // Si on veut écrire un '0'
        Delai_us(60);      // On tient la ligne basse longtemps
        Mode_Entree();     // On relâche
        Delai_us(10);
    }
}

// Lit un seul bit venant du capteur
static uint8_t Onewire_ReadBit(void) {
    uint8_t bit_lu = 0;

    Mode_Sortie();
    PORT_ONEWIRE->ODR &= ~(1 << PIN_ONEWIRE); // Tirer la ligne à 0
    Delai_us(6);

    Mode_Entree(); // Relâcher pour laisser le capteur parler
    Delai_us(9);   // Attendre un peu

    // Lire l'état de la broche
    if (PORT_ONEWIRE->IDR & (1 << PIN_ONEWIRE)) {
        bit_lu = 1;
    }

    Delai_us(55); // Attendre la fin du créneau
    return bit_lu;
}

// --- FONCTIONS PUBLIQUES ---

uint8_t Onewire_Reset(void) {
    uint8_t presence = 0;

    Mode_Sortie();
    PORT_ONEWIRE->ODR &= ~(1 << PIN_ONEWIRE); // Tirer à 0
    Delai_us(480); // Signal Reset long (480µs)

    Mode_Entree(); // Relâcher
    Delai_us(70);  // Attendre la réponse du capteur

    // Si la ligne est basse, c'est que le capteur est là
    if (!(PORT_ONEWIRE->IDR & (1 << PIN_ONEWIRE))) {
        presence = 1;
    }

    Delai_us(410); // Attendre la fin du cycle
    return presence;
}

void Onewire_WriteByte(uint8_t octet) {
    for (int i = 0; i < 8; i++) {
        // Envoie bit par bit, en commençant par le poids faible
        Onewire_WriteBit(octet & 0x01);
        octet >>= 1; // Décalage vers la droite
    }
}

uint8_t Onewire_ReadByte(void) {
    uint8_t octet = 0;
    for (int i = 0; i < 8; i++) {
        octet >>= 1;
        if (Onewire_ReadBit()) {
            octet |= 0x80; // Ajoute le bit lu
        }
    }
    return octet;
}

void Onewire_ReadBytes(uint8_t *buffer, uint8_t longueur) {
    for (uint8_t i = 0; i < longueur; i++) {
        buffer[i] = Onewire_ReadByte();
    }
}

float Onewire_ConvertToCelsius(uint8_t *donnees) {
    // Les deux premiers octets contiennent la température brute
    int16_t temp_brute = (donnees[1] << 8) | donnees[0];
    // Le capteur donne la température x 16 (résolution 12 bits)
    return (float)temp_brute / 16.0f;
}
